import React, { Component } from 'react';
import Friend from "./freind"

export default class followList extends Component {
    constructor(props) {
        super(props)

        this.state = {
            friends: [
                {
                    id: 1,
                    status: "following",
                },
                {
                    id: 2,
                    status: "follow",
                },
                {
                    id: 3,
                    status: "following",
                },
                {
                    id: 4,
                    status: "following",
                },
                {
                    id: 5,
                    status: "follow",
                },
                {
                    id: 6,
                    status: "follow",
                },
                {
                    id: 7,
                    status: "following",
                },
                {
                    id: 8,
                    status: "following",
                },
                {
                    id: 9,
                    status: "following",
                }

            ]
        }
    }
    render() {
        if (this.props.following) {
            return (
                this.state.friends
                    .filter(friend => friend.status === "following")
                    .map(friend => <Friend friend={friend} key={friend.id} />)
            )
        } else {
            return (
                this.state.friends.map(friend => <Friend
                    friend={friend}
                    key={friend.id}
                />)
            )
        }

    }
}
