import React, { Component } from 'react'

export default class notification extends Component {
    render() {
        return (
            <div>
                 notification
            </div>
        )
    }
}
