import React, { Component } from 'react'

export default class search extends Component {
    render() {
        return (
            <div>
                search
            </div>
        )
    }
}
