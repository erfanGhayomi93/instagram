import React, { Component } from 'react';
import Username from "./username";
import FollowList from "./followList"

export default class follow extends Component {
    constructor(props) {
        super(props)

        this.changeTitle = this.changeTitle.bind(this)

        this.state = {
            title: this.props.title
        }
    }

    changeTitle(title) {
        if (this.state.title === title)
            return

        this.setState({
            title
        })
    }

    render() {
        const { title } = this.state
        return (
            <div>
                <Username
                    title="follow"
                    backProps={(name) => this.props.avatarProps.call(null, name)}
                />
                <div className="followPage pt-3">
                    <div className="d-flex text-center">
                        <article
                            className={title === "follower" ? "flex-grow-1 border-bootom pb-1" : "flex-grow-1 pb-1"}
                            onClick={() => this.changeTitle('follower')}
                        >708 Followers</article>
                        <article
                            className={title === "following" ? "flex-grow-1 border-bootom pb-1" : "flex-grow-1 pb-1"}
                            onClick={() => this.changeTitle('following')}
                        >760 Following</article>
                    </div>

                    {
                        title === "follower" ?
                            <FollowList />
                            : title === "following" ?
                            <FollowList following="following"/>
                                : ""

                    }
                </div>
            </div>
        )
    }
}
