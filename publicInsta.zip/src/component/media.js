import React, { Component } from 'react'

export default class media extends Component {
    render() {
        return (
            <div>
                media
            </div>
        )
    }
}
