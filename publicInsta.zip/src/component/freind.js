import React, { Component } from 'react';
import faker from "faker/locale/en"

export default class freind extends Component {
    render() {
        let img_url = faker.image.avatar();
        let fullName = faker.name.findName();
        let userName = faker.internet.userName();
        const { friend } = this.props;
        return (
            <div className="friend">
                <div className="item">
                    <article>
                        <img src={img_url} alt="alt"/>
                    </article>
                    <article className="pl-1">
                        <p>{fullName}</p>
                        <p className="text-muted">{userName}</p>
                    </article>
                </div>
                <div className="item text-right justify-content-end">
                    <article className="pr-1">
                        <span className={friend.status === "follow" ? "status btn-primary" : "status"}>{friend.status}</span>
                    </article>
                    <article className="p-1">...</article>
                </div>
            </div>
        )
    }
}
