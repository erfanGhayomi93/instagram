import React from 'react';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Main from "./main";
import 'font-awesome/css/font-awesome.min.css'

function App() {
  return (
      <Main />
  );
}

export default App;
